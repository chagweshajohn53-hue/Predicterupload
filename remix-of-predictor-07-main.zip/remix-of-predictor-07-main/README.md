# Remix of predictor 07

Build a web application that acts as a unified AI proxy and playground interlinking free models across multiple providers to overcome free-tier rate limits with automated fallback.

Core requirements:
1. Settings & Provider Keys Management:
- Clean frontend dashboard to securely enter, test, and store API credentials for:
  - Google Gemini (API Key)
  - Groq (API Key)
  - OpenRouter (API Key)
  - Cloudflare Workers AI (Account ID and API Token)
- Credentials stored securely in client storage / local vault with masked inputs and connection test buttons.

2. Auto-Failover Router Engine:
- Configurable priority chain of models (e.g. Groq Llama 3.3 70B -> Gemini Flash -> OpenRouter Free Models -> Cloudflare Workers AI).
- Automatic detection of rate limits (HTTP 429, quota errors, exhausted tokens).
- Seamless failover: automatically re-dispatches the prompt with the full conversation history to the next active provider without losing chat context.
- Live status tracking of rate-limit reset headers (retry-after, requests remaining, cooldown timers).

3. Interactive Playground & Features:
- Chat playground showing real-time streaming, latency, token metrics, and active model badge.
- Visual failover indicator showing when a fallback was triggered and which provider picked it up.
- Multi-modality tabs: Text chat, Image generation (Cloudflare Flux/SDXL), and Voice/Transcription (Groq Whisper, Cloudflare Aura).
- Proxy / code snippet export: provides an OpenAI-compatible request helper and cURL snippet so users can use this unified failover pipeline in their own apps.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/584349b0-1896-45f4-bbe1-46916fb898f7).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
