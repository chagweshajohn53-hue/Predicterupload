import { useEffect, useState, type ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { connectCloud, disconnectCloud } from "@/lib/vault";

export function AuthGate({ children }: { children: ReactNode }) {
  const [status, setStatus] = useState<"loading" | "in" | "out">("loading");

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "SIGNED_OUT") {
        disconnectCloud();
        setStatus("out");
      } else if (session?.user && (event === "SIGNED_IN" || event === "INITIAL_SESSION")) {
        void connectCloud(session.user.id).then(() => setStatus("in"));
      } else if (event === "INITIAL_SESSION") {
        setStatus("out");
      }
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  if (status === "loading") return <div className="grid min-h-screen place-items-center font-mono text-xs text-muted-foreground">unlocking…</div>;
  if (status === "out") return <SignIn />;
  return <>{children}</>;
}

function SignIn() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [mode, setMode] = useState<"unlock" | "create">("unlock");

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setErr("");
    setNote("");
    if (mode === "create") {
      const { data, error } = await supabase.auth.signUp({ email, password });
      if (error) setErr(/already/i.test(error.message) ? "That email already has an account — unlock instead." : "Couldn't create the account. Try another password.");
      else if (!data.session) setNote("Account created. Check your email to confirm it, then unlock.");
      setBusy(false);
      return;
    }
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) setErr("Wrong email or password");
    setBusy(false);
  }

  return (
    <div className="grid min-h-screen place-items-center px-4">
      <form onSubmit={submit} className="w-full max-w-sm space-y-3 rounded-lg border border-border bg-card p-6">
        <h1 className="font-mono text-sm font-semibold">failover<span className="text-primary">/</span>relay — locked</h1>
        <p className="text-xs text-muted-foreground">{mode === "unlock" ? "Unlock with your saved email and password." : "First time here? Set the email and password you'll unlock with."}</p>
        <input className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm" type="email" placeholder="Email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        <input className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm" type="password" placeholder="Password" autoComplete={mode === "create" ? "new-password" : "current-password"} value={password} onChange={(e) => setPassword(e.target.value)} required minLength={mode === "create" ? 8 : undefined} />
        {err && <p className="text-xs text-destructive">{err}</p>}
        {note && <p className="text-xs text-success">{note}</p>}
        <button disabled={busy} className="w-full rounded-md bg-primary px-3 py-2 font-mono text-xs uppercase text-primary-foreground disabled:opacity-50">{busy ? "…" : mode === "unlock" ? "Unlock" : "Create account"}</button>
        <button type="button" onClick={() => { setMode((m) => (m === "unlock" ? "create" : "unlock")); setErr(""); setNote(""); }} className="w-full text-center font-mono text-[10px] uppercase text-muted-foreground hover:text-foreground">
          {mode === "unlock" ? "No account yet? Create one" : "Already have one? Unlock"}
        </button>
      </form>
    </div>
  );
}

export function SignOutButton() {
  return (
    <button onClick={() => void supabase.auth.signOut()} className="rounded-md px-3 py-1.5 font-mono text-xs uppercase text-muted-foreground hover:text-foreground">
      Lock
    </button>
  );
}
