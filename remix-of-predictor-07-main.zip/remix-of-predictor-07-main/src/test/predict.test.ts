import { describe, expect, it } from "vitest";
import { normalizeSignal } from "@/lib/predict";

describe("normalizeSignal", () => {
  it("falls back to HOLD for unknown actions", () => expect(normalizeSignal({ signal: "maybe" as never }).signal).toBe("HOLD"));
  it("clamps confidence to 0-100", () => expect(normalizeSignal({ signal: "BUY", confidence: 140 }).confidence).toBe(100));
  it("accepts lowercase sell", () => expect(normalizeSignal({ signal: "sell" as never }).signal).toBe("SELL"));
});
