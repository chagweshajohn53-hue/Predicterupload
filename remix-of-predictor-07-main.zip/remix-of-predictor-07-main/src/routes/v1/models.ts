import { createFileRoute } from "@tanstack/react-router";
import { handleModels, openAIOptions } from "@/lib/openai-api";

export const Route = createFileRoute("/v1/models")({
  server: { handlers: {
    OPTIONS: openAIOptions,
    GET: async ({ request }) => {
      const { lookupRelayToken } = await import("@/lib/relay-auth");
      return handleModels(request, lookupRelayToken);
    },
  } },
});