import { runChat } from "./engine";
import { parseJsonLenient } from "./json-repair";
import type { Msg } from "./providers";
import { getVault } from "./vault";
import { zepAdd, zepCreateGraph, zepSearch } from "./zep";
import { claudeAnalysis } from "./claude.functions";

export type Entity = { name: string; type: string; summary: string };
export type Relation = { source: string; target: string; label: string };
export type Agent = { name: string; role: string; persona: string; stance: string; platform: "twitter" | "reddit" };
export type Post = { id: string; round: number; author: string; platform: "twitter" | "reddit"; kind: "post" | "reply" | "like"; content: string; replyTo?: string; likes: number };
export type Sim = {
  id: string;
  title: string;
  seed: string;
  question: string;
  createdAt: number;
  stage: "graph" | "agents" | "simulating" | "report" | "done" | "error";
  entities: Entity[];
  relations: Relation[];
  agents: Agent[];
  posts: Post[];
  rounds: number;
  roundsDone: number;
  injections: { round: number; text: string }[];
  report: string;
  zepGraph?: string;
  log: string[];
  error?: string;
};

const uid = () => Math.random().toString(36).slice(2, 10);

/** One failover-backed completion, collected as text. */
export async function ask(messages: Msg[], signal?: AbortSignal): Promise<{ text: string; model: string }> {
  let text = "";
  const r = await runChat({ messages, ...(signal ? { signal } : {}), onToken: (t) => (text += t), onAttempt: () => {}, onStart: () => { text = ""; } });
  if (!r.entry) throw new Error("Every model in your Router is unavailable (keys missing or limits hit).");
  return { text, model: r.entry.model };
}

export function parseJson<T>(text: string): T {
  return parseJsonLenient<T>(text);
}

async function askJson<T>(system: string, user: string, signal?: AbortSignal): Promise<T> {
  let last: unknown;
  for (let i = 0; i < 2; i++) {
    const { text } = await ask([{ role: "system", content: system + "\nRespond with valid JSON only, no prose. Double-quote every property name and string value." }, { role: "user", content: user + (i ? `\nYour previous reply was invalid JSON (${String(last).slice(0, 160)}). Correct the syntax; do not use bare words as string values.` : "") }], signal);
    try { return parseJson<T>(text); } catch (e) { last = e; }
  }
  throw last;
}

export function newSim(seed: string, question: string, rounds: number): Sim {
  return {
    id: uid(), title: question.slice(0, 60) || "Untitled simulation", seed, question, createdAt: Date.now(), stage: "graph",
    entities: [], relations: [], agents: [], posts: [], rounds, roundsDone: 0, injections: [], report: "", log: [],
  };
}

type Update = (fn: (s: Sim) => Sim) => void;
const log = (u: Update, m: string) => u((s) => ({ ...s, log: [...s.log, `${new Date().toLocaleTimeString()} ${m}`] }));

async function memory(sim: Sim, q: string): Promise<string[]> {
  const key = getVault().keys.zep;
  if (!key || !sim.zepGraph) return [];
  try { return await zepSearch(key, sim.zepGraph, q); } catch { return []; }
}
async function remember(sim: Sim, text: string) {
  const key = getVault().keys.zep;
  if (!key || !sim.zepGraph) return;
  try { await zepAdd(key, sim.zepGraph, text); } catch { /* memory is best-effort */ }
}

export async function buildWorld(sim: Sim, u: Update, agentCount: number, signal?: AbortSignal): Promise<Sim> {
  let cur = sim;
  const up: Update = (fn) => { cur = fn(cur); u(() => cur); };

  // 1. Graph construction
  log(up, "Extracting entities and relationships from seed…");
  const g = await askJson<{ entities: Entity[]; relations: Relation[] }>(
    "You build knowledge graphs for social simulations. Extract people, organisations, media, groups and concepts that matter for the prediction question.",
    `Prediction question: ${sim.question}\n\nSeed material:\n${sim.seed.slice(0, 12000)}\n\nReturn JSON shaped like {"entities":[{"name":"Entity name","type":"concept","summary":"Brief summary"}],"relations":[{"source":"Entity name","target":"Another entity","label":"RELATED_TO"}]} with 6-20 entities. label is SCREAMING_SNAKE_CASE.`,
    signal,
  );
  up((s) => ({ ...s, entities: g.entities ?? [], relations: (g.relations ?? []).filter((r) => r.source && r.target) }));
  log(up, `Graph: ${g.entities?.length ?? 0} entities, ${g.relations?.length ?? 0} relations`);

  const key = getVault().keys.zep;
  if (key) {
    const gid = `mirofish-${sim.id}`;
    try {
      await zepCreateGraph(key, gid, sim.title);
      up((s) => ({ ...s, zepGraph: gid }));
      await zepAdd(key, gid, `Prediction question: ${sim.question}\n\n${sim.seed}`);
      log(up, "Seed stored in Zep graph memory");
    } catch (e) {
      log(up, `Zep memory unavailable, continuing with local memory (${(e as Error).message.slice(0, 80)})`);
    }
  } else log(up, "No Zep key — using local memory only");

  // 2. Environment setup
  up((s) => ({ ...s, stage: "agents" }));
  log(up, "Generating agent personas…");
  const a = await askJson<{ agents: Agent[] }>(
    "You design diverse, realistic social-media agents for a public-opinion simulation. Mix individuals, organisations, media and ordinary citizens with differing stances.",
    `Question: ${sim.question}\nEntities: ${JSON.stringify(cur.entities).slice(0, 6000)}\n\nCreate exactly ${agentCount} agents. Return JSON shaped like {"agents":[{"name":"Analyst","role":"Market analyst","persona":"Personality and motives. Speaking style.","stance":"skeptical","platform":"twitter"}]}. Persona must be 2 sentences. Vary stance between supportive, opposed, neutral and skeptical. Platform must be the quoted string "twitter" or "reddit".`,
    signal,
  );
  up((s) => ({ ...s, agents: (a.agents ?? []).slice(0, agentCount), stage: "simulating" }));
  log(up, `${cur.agents.length} agents ready`);
  return cur;
}

export async function runRound(sim: Sim, u: Update, signal?: AbortSignal): Promise<Sim> {
  let cur = sim;
  const up: Update = (fn) => { cur = fn(cur); u(() => cur); };
  const round = sim.roundsDone + 1;
  const feed = sim.posts.slice(-30).map((p) => `[${p.id}] (${p.platform}, r${p.round}) ${p.author}${p.replyTo ? ` ↳${p.replyTo}` : ""}: ${p.content} (♥${p.likes})`).join("\n");
  const events = sim.injections.filter((i) => i.round === round).map((i) => i.text);
  const mem = await memory(sim, `${sim.question} ${events.join(" ")} ${sim.posts.slice(-3).map((p) => p.content).join(" ")}`);

  log(up, `Round ${round}: agents acting…`);
  const res = await askJson<{ actions: { author: string; kind: "post" | "reply" | "like" | "idle"; content?: string; replyTo?: string }[] }>(
    "You are the OASIS-style engine of a social simulation. Each agent acts strictly in character, reacting to the feed, memory and breaking events. Opinions may shift, coalitions form, conflicts escalate or cool. Keep posts short and realistic.",
    `Question being predicted: ${sim.question}\nRound ${round} of ${sim.rounds}.\n\nAgents:\n${sim.agents.map((a) => `- ${a.name} (${a.role}, ${a.stance}, ${a.platform}): ${a.persona}`).join("\n")}\n\n${mem.length ? `Long-term memory facts:\n${mem.map((m) => "- " + m).join("\n")}\n\n` : ""}${events.length ? `BREAKING EVENT injected this round: ${events.join(" | ")}\n\n` : ""}Recent feed:\n${feed || "(empty — first round)"}\n\nReturn JSON shaped like {"actions":[{"author":"Exact agent name","kind":"post","content":"Post text","replyTo":"p1"}]} with one action per agent. Kind must be a quoted string: post, reply, like or idle. Omit replyTo unless replying or liking; omit content for likes and idle.`,
    signal,
  );
  const names = new Set(sim.agents.map((a) => a.name));
  const newPosts: Post[] = [];
  const likes: Record<string, number> = {};
  for (const act of res.actions ?? []) {
    if (!names.has(act.author) || act.kind === "idle") continue;
    if (act.kind === "like") { if (act.replyTo) likes[act.replyTo] = (likes[act.replyTo] ?? 0) + 1; continue; }
    if (!act.content) continue;
    const agent = sim.agents.find((a) => a.name === act.author)!;
    newPosts.push({ id: `p${sim.posts.length + newPosts.length + 1}`, round, author: act.author, platform: agent.platform, kind: act.kind, content: act.content, likes: 0, ...(act.kind === "reply" && act.replyTo ? { replyTo: act.replyTo } : {}) });
  }
  up((s) => ({
    ...s,
    posts: [...s.posts.map((p) => (likes[p.id] ? { ...p, likes: p.likes + likes[p.id]! } : p)), ...newPosts],
    roundsDone: round,
  }));
  log(up, `Round ${round}: ${newPosts.length} posts, ${Object.values(likes).reduce((a, b) => a + b, 0)} likes`);
  void remember(cur, `Round ${round}${events.length ? ` (event: ${events.join("; ")})` : ""}:\n${newPosts.map((p) => `${p.author}: ${p.content}`).join("\n")}`);
  return cur;
}

export async function writeReport(sim: Sim, u: Update, signal?: AbortSignal): Promise<Sim> {
  let cur: Sim = { ...sim, stage: "report" };
  u(() => cur);
  const mem = await memory(sim, sim.question);
  signal?.throwIfAborted();
  const { text } = await claudeAnalysis({ data: { task: "review", images: [], messages: [
    { role: "system", content: "You are ReportAgent, an analyst who studies a completed multi-agent social simulation and writes a prediction report in Markdown." },
    { role: "user", content: `Question: ${sim.question}\n\nAgents:\n${sim.agents.map((a) => `- ${a.name} (${a.role}, initial stance ${a.stance})`).join("\n")}\n\nInjected events: ${sim.injections.map((i) => `r${i.round}: ${i.text}`).join("; ") || "none"}\n\n${mem.length ? `Memory facts:\n${mem.join("\n")}\n\n` : ""}Full simulated feed:\n${sim.posts.map((p) => `(r${p.round}) ${p.author}: ${p.content} ♥${p.likes}`).join("\n").slice(-14000)}\n\nWrite: ## Prediction (direct answer with confidence %), ## How opinion evolved (by round), ## Key actors & coalitions, ## Turning points, ## Risks & alternative futures, ## Recommendations.` },
  ] } });
  signal?.throwIfAborted();
  cur = { ...cur, report: text, stage: "done" };
  u(() => cur);
  return cur;
}

export async function interview(sim: Sim, who: string | "ReportAgent", history: Msg[], signal?: AbortSignal) {
  const agent = sim.agents.find((a) => a.name === who);
  const mine = sim.posts.filter((p) => p.author === who).map((p) => `(r${p.round}) ${p.content}`).join("\n");
  const mem = await memory(sim, history[history.length - 1]?.content ?? sim.question);
  const system = agent
    ? `You are ${agent.name}, ${agent.role}. ${agent.persona} Initial stance: ${agent.stance}. You lived through a simulation about "${sim.question}". Your posts:\n${mine || "(none)"}\n${mem.length ? `What you remember:\n${mem.join("\n")}` : ""}\nStay fully in character.`
    : `You are ReportAgent. Answer questions about this simulation using the report and feed.\nReport:\n${sim.report.slice(0, 6000)}\nFeed:\n${sim.posts.map((p) => `${p.author}: ${p.content}`).join("\n").slice(-6000)}`;
  if (!agent) {
    signal?.throwIfAborted();
    const result = await claudeAnalysis({ data: { task: "review", images: [], messages: [{ role: "system", content: system }, ...history] } });
    signal?.throwIfAborted();
    return result;
  }
  return ask([{ role: "system", content: system }, ...history], signal);
}

// Local persistence
const KEY = "mirofish-sims-v1";
export function loadSims(): Sim[] {
  try { return JSON.parse(localStorage.getItem(KEY) ?? "[]") as Sim[]; } catch { return []; }
}
export function saveSims(s: Sim[]) {
  try { localStorage.setItem(KEY, JSON.stringify(s.slice(0, 20))); } catch { /* quota */ }
}

const imageDescriptions = new Map<string, string>();

/** Read charts only through image-capable entries, caching successful repeated requests in memory. */
export async function describeImages(images: string[], context: string, signal?: AbortSignal): Promise<string> {
  if (!images.length) return "";
  signal?.throwIfAborted();
  const key = JSON.stringify([context.slice(0, 500), images]);
  const cached = imageDescriptions.get(key);
  if (cached) return cached;
  const result = await claudeAnalysis({ data: { task: "pictures", images, messages: [{ role: "user", content: context.slice(0, 4000) }] } });
  signal?.throwIfAborted();
  if (!result.text.trim()) throw new Error("Claude returned no image-reading analysis.");
  const description = result.text.trim();
  if (imageDescriptions.size >= 4) {
    const oldest = imageDescriptions.keys().next().value;
    if (oldest !== undefined) imageDescriptions.delete(oldest);
  }
  imageDescriptions.set(key, description);
  return description;
}
