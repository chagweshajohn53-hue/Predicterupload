import { useSyncExternalStore } from "react";

export type ProviderId = "groq" | "gemini" | "openrouter" | "cloudflare";
export type Keys = { groq: string; gemini: string; openrouter: string; cfAccount: string; cfToken: string; apiToken: string; zep: string; extra?: ExtraKeys[] };
export type ExtraKeys = Partial<Pick<Keys, "groq" | "gemini" | "openrouter" | "cfAccount" | "cfToken">>;
export { expandChain, type PooledEntry } from "./pool";

export type ChainEntry = { id: string; provider: ProviderId; model: string; enabled: boolean };
export type Cooldown = { until: number; reason: string };
export type LiveStatus = { remainingReq?: string | undefined; remainingTok?: string | undefined; resetReq?: string | undefined; lastStatus?: number | undefined; at: number };

export type VaultState = {
  keys: Keys;
  chain: ChainEntry[];
  cooldowns: Record<string, Cooldown>;
  status: Record<string, LiveStatus>;
};

const uid = () => Math.random().toString(36).slice(2, 9);

export const DEFAULT_CHAIN: ChainEntry[] = [
  { id: "c1", provider: "groq", model: "llama-3.3-70b-versatile", enabled: true },
  { id: "c2", provider: "gemini", model: "gemini-3.5-flash-lite", enabled: true },
  { id: "c3", provider: "openrouter", model: "meta-llama/llama-3.3-70b-instruct:free", enabled: true },
  { id: "c4", provider: "openrouter", model: "deepseek/deepseek-chat-v3-0324:free", enabled: true },
  { id: "c8", provider: "openrouter", model: "qwen/qwen-2.5-72b-instruct:free", enabled: true },
  { id: "c5", provider: "cloudflare", model: "@cf/meta/llama-3.3-70b-instruct-fp8-fast", enabled: true },
  { id: "c9", provider: "groq", model: "meta-llama/llama-4-scout-17b-16e-instruct", enabled: true },
  { id: "c10", provider: "groq", model: "qwen/qwen3-32b", enabled: true },
  { id: "c11", provider: "groq", model: "llama-3.1-8b-instant", enabled: true },
  { id: "c12", provider: "gemini", model: "gemini-flash-lite-latest", enabled: true },
  { id: "c13", provider: "gemini", model: "gemini-3.1-flash-lite", enabled: true },
  { id: "c14", provider: "openrouter", model: "deepseek/deepseek-r1:free", enabled: true },
  { id: "c15", provider: "openrouter", model: "google/gemma-3-27b-it:free", enabled: true },
  { id: "c16", provider: "openrouter", model: "mistralai/mistral-small-3.2-24b-instruct:free", enabled: true },
  { id: "c17", provider: "openrouter", model: "nvidia/llama-3.1-nemotron-ultra-253b-v1:free", enabled: true },
  { id: "c18", provider: "openrouter", model: "qwen/qwen3-235b-a22b:free", enabled: true },
  { id: "c19", provider: "openrouter", model: "liquid/lfm-2.5-2.6b:free", enabled: true },
  { id: "c22", provider: "cloudflare", model: "@cf/qwen/qwq-32b", enabled: true },
];

const DEFAULT: VaultState = {
  keys: { groq: "", gemini: "", openrouter: "", cfAccount: "", cfToken: "", apiToken: "", zep: "" },
  chain: DEFAULT_CHAIN,
  cooldowns: {},
  status: {},
};

const KEY = "failover-vault-v1";
let state: VaultState = DEFAULT;
let loaded = false;
const listeners = new Set<() => void>();

function load() {
  if (loaded || typeof window === "undefined") return;
  loaded = true;
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) { const saved = JSON.parse(raw); state = { ...DEFAULT, ...saved, keys: cleanKeys(saved.keys), chain: cleanChain(saved.chain ?? DEFAULT_CHAIN) }; }
  } catch {
    /* ignore */
  }
}

export function getVault(): VaultState {
  load();
  return state;
}

export function setVault(fn: (s: VaultState) => VaultState) {
  load();
  state = fn(state);
  try {
    localStorage.setItem(KEY, JSON.stringify(state));
  } catch {
    /* ignore */
  }
  listeners.forEach((l) => l());
  scheduleCloudSave();
}

// ---- Cloud sync (keys + router order follow the signed-in account) ----
let cloudUser: string | null = null;
let saveTimer: ReturnType<typeof setTimeout> | undefined;
let lastSaved = "";

function scheduleCloudSave() {
  if (!cloudUser) return;
  clearTimeout(saveTimer);
  saveTimer = setTimeout(async () => {
    const payload = { keys: state.keys, chain: state.chain };
    const json = JSON.stringify(payload);
    if (json === lastSaved || !cloudUser) return;
    const { supabase } = await import("@/integrations/supabase/client");
    const { error } = await supabase.from("vaults").upsert({ user_id: cloudUser, data: payload, updated_at: new Date().toISOString() });
    if (!error) lastSaved = json;
  }, 600);
}

export async function connectCloud(userId: string) {
  cloudUser = userId;
  const { supabase } = await import("@/integrations/supabase/client");
  const { data } = await supabase.from("vaults").select("data").eq("user_id", userId).maybeSingle();
  const remote = (data?.data ?? null) as Partial<VaultState> | null;
  if (remote && (remote.keys || remote.chain)) {
    lastSaved = JSON.stringify({ keys: remote.keys, chain: remote.chain });
    setVault((s) => ({ ...s, keys: cleanKeys(remote.keys), chain: mergeChain(cleanChain(remote.chain ?? s.chain)) }));
  } else {
    scheduleCloudSave();
  }
}

export function disconnectCloud() {
  cloudUser = null;
  lastSaved = "";
  clearTimeout(saveTimer);
  state = DEFAULT;
  try { localStorage.removeItem(KEY); } catch { /* ignore */ }
  listeners.forEach((l) => l());
}

export function useVault(): VaultState {
  return useSyncExternalStore(
    (l) => {
      listeners.add(l);
      return () => listeners.delete(l);
    },
    getVault,
    () => DEFAULT,
  );
}

export const newEntry = (provider: ProviderId, model: string): ChainEntry => ({
  id: uid(),
  provider,
  model,
  enabled: true,
});

export const PROVIDER_LABEL: Record<ProviderId, string> = {
  groq: "Groq",
  gemini: "Gemini",
  openrouter: "OpenRouter",
  cloudflare: "Cloudflare",
};

function mergeChain(c: ChainEntry[]) {
  const have = new Set(c.map((e) => e.provider + e.model));
  return [...c, ...DEFAULT_CHAIN.filter((d) => !have.has(d.provider + d.model)).map((d) => ({ ...d, id: uid() }))];
}

export function cleanKeys(raw: Partial<Keys> = {}): Keys {
  return { ...Object.fromEntries(Object.keys(DEFAULT.keys).map(k => [k, raw[k as keyof Keys] ?? ""])), extra: (raw.extra ?? []).map(x => Object.fromEntries(Object.entries(x).filter(([k]) => ["groq", "gemini", "openrouter", "cfAccount", "cfToken"].includes(k)))) } as Keys;
}
export function cleanChain(chain: ChainEntry[]): ChainEntry[] {
  return chain.filter(e => Object.hasOwn(PROVIDER_LABEL, e.provider));
}
