import { runHostedChat, type Fx, type Hop } from "./hub";
import { parseJsonLenient } from "./json-repair";
import type { Msg } from "./providers";
import type { ChainEntry, Keys } from "./vault";
import { CHART_PROMPT, REVIEW_PROMPT } from "./claude";

export type Reviewer = (messages: Msg[], images?: string[]) => Promise<{ text: string; model: string }>;

// Server-side Swarm predictor: personas -> debate rounds -> consensus signal.
// Every LLM step runs through runHostedChat, so it inherits the Router failover.

export type Persona = { name: string; role: string; bias: string };
export type Turn = { round: number; agent: string; action: "BUY" | "SELL" | "HOLD"; confidence: number; argument: string };
export type Signal = { signal: "BUY" | "SELL" | "HOLD"; confidence: number; entry: number | null; stop_loss: number | null; take_profit: number | null; rationale: string };

export function extractJson<T>(text: string): T {
  return parseJsonLenient<T>(text);
}

const num = (v: unknown) => (typeof v === "number" && Number.isFinite(v) ? v : null);

export function normalizeSignal(raw: Partial<Signal> | null | undefined): Signal {
  const s = String(raw?.signal ?? "").toUpperCase();
  const signal = s === "BUY" || s === "SELL" ? s : "HOLD";
  const c = Number(raw?.confidence);
  return {
    signal,
    confidence: Number.isFinite(c) ? Math.max(0, Math.min(100, Math.round(c))) : 0,
    entry: num(raw?.entry), stop_loss: num(raw?.stop_loss), take_profit: num(raw?.take_profit),
    rationale: String(raw?.rationale ?? "").slice(0, 500),
  };
}

export const FALLBACK: Persona[] = [
  { name: "Central Banker", role: "policy maker", bias: "rates and inflation driven" },
  { name: "Macro Fund", role: "hedge fund PM", bias: "trend and macro divergence" },
  { name: "Retail Scalper", role: "retail trader", bias: "short-term momentum" },
  { name: "Quant", role: "systematic trader", bias: "indicators and statistics" },
  { name: "Bank FX Desk", role: "dealer", bias: "flows and liquidity" },
  { name: "Contrarian", role: "independent trader", bias: "fades crowded moves" },
  { name: "Risk Manager", role: "risk officer", bias: "capital preservation" },
  { name: "Economist", role: "sell-side analyst", bias: "data surprises" },
  { name: "Swing Trader", role: "technical analyst", bias: "support and resistance" },
  { name: "Carry Trader", role: "fund manager", bias: "interest-rate differentials" },
];

/** Accepts {agents:[...]}, a bare array, or any object holding an array of personas. */
export function pickPersonas(raw: unknown): Persona[] {
  let arr: unknown = raw;
  if (raw && typeof raw === "object" && !Array.isArray(raw)) {
    const o = raw as Record<string, unknown>;
    arr = o["agents"] ?? o["personas"] ?? o["participants"] ?? Object.values(o).find(Array.isArray);
  }
  if (!Array.isArray(arr)) return [];
  return arr.flatMap((a) => {
    if (typeof a === "string") return [{ name: a, role: "market participant", bias: "" }];
    if (!a || typeof a !== "object") return [];
    const o = a as Record<string, unknown>;
    const name = String(o["name"] ?? o["agent"] ?? o["role"] ?? "").trim();
    return name ? [{ name, role: String(o["role"] ?? o["type"] ?? "trader"), bias: String(o["bias"] ?? o["view"] ?? o["stance"] ?? "") }] : [];
  });
}

export async function runPrediction(fx: Fx, keys: Keys, chain: ChainEntry[], input: { seed: string; question: string; agents: number; rounds: number; images?: string[] }, reviewer?: Reviewer) {
  const hops: Hop[] = [];
  const models = new Set<string>();
  const unavailable = new Set<string>();
  const ask = async <T>(system: string, user: string, finalReview = false): Promise<T> => {
    for (let i = 0; i < 2; i++) {
      const msgs: Msg[] = [{ role: "system", content: system + "\nRespond with valid JSON only, no prose." }, { role: "user", content: user }];
      if (finalReview && reviewer) {
        const r = await reviewer(msgs);
        models.add(`anthropic:${r.model}`);
        hops.push({ model: r.model, ok: true, detail: "final review" });
        try { return extractJson<T>(r.text); } catch { continue; }
      }
      const r = await runHostedChat(fx, keys, chain, msgs, { temperature: 0.1, unavailable });
      hops.push(...r.hops);
      if (!r.out || !r.model) throw new Error("All providers exhausted");
      models.add(`${r.model.provider}:${r.model.model}`);
      try { return extractJson<T>(r.out.choices[0]?.message.content ?? ""); } catch { /* retry */ }
    }
    throw new Error("Model did not return valid JSON");
  };

  let chart = "";
  if (input.images?.length) {
    if (!reviewer) throw new Error("Claude picture reader is unavailable");
    const r = await reviewer([{ role: "system", content: CHART_PROMPT }, { role: "user", content: input.question }], input.images);
    chart = r.text;
    models.add(`anthropic:${r.model}`);
    hops.push({ model: r.model, ok: true, detail: "picture extraction" });
  }
  const ctx = `MARKET CONTEXT:\n${input.seed}\n\nCHART EVIDENCE:\n${chart || "No pictures supplied"}\n\nQUESTION: ${input.question}`;

  // 1. Personas
  let personas: Persona[] = [];
  try {
    const p = await ask<unknown>(
      `Create ${input.agents} distinct market participants (e.g. central banker, macro hedge fund, retail scalper, quant, bank FX desk, contrarian). Return {"agents":[{"name","role","bias"}]}.`,
      ctx,
    );
    personas = pickPersonas(p).slice(0, input.agents);
  } catch (e) {
    if (e instanceof Error && /exhausted/.test(e.message)) throw e;
  }
  if (!personas.length) personas = FALLBACK.slice(0, input.agents);

  // 2. Debate rounds (one batched call per round)
  const turns: Turn[] = [];
  for (let round = 1; round <= input.rounds; round++) {
    const prior = turns.slice(-input.agents * 2).map((t) => `R${t.round} ${t.agent}: ${t.action} (${t.confidence}%) - ${t.argument}`).join("\n") || "(none yet)";
    const r = await ask<{ turns: Omit<Turn, "round">[] }>(
      `You simulate round ${round} of a trading-floor debate. Each agent reacts to the data and to others' arguments, staying in character, and may change their mind. Return {"turns":[{"agent","action":"BUY|SELL|HOLD","confidence":0-100,"argument":"one or two sentences"}]} with one turn per agent.`,
      `${ctx}\n\nAGENTS:\n${personas.map((a) => `- ${a.name} (${a.role}): ${a.bias}`).join("\n")}\n\nPREVIOUS ARGUMENTS:\n${prior}`,
    );
    for (const t of r.turns ?? []) {
      const n = normalizeSignal({ signal: t.action, confidence: t.confidence });
      turns.push({ round, agent: String(t.agent), action: n.signal, confidence: n.confidence, argument: String(t.argument ?? "").slice(0, 400) });
    }
  }

  // 3. Consensus
  const final = await ask<Partial<Signal> & { report?: string }>(
    `${REVIEW_PROMPT} Return {"signal":"BUY|SELL|HOLD","confidence":0-100,"entry":number|null,"stop_loss":number|null,"take_profit":number|null,"rationale":"one sentence","report":"short markdown summary"}.`,
    `${ctx}\n\nDEBATE:\n${turns.map((t) => `R${t.round} ${t.agent}: ${t.action} (${t.confidence}%) - ${t.argument}`).join("\n")}`,
    true,
  );
  const last = turns.filter((t) => t.round === input.rounds);
  const votes = { BUY: 0, SELL: 0, HOLD: 0 };
  for (const t of last) votes[t.action]++;

  return { ...normalizeSignal(final), decision_source: reviewer ? "claude_final_review" : "chain_consensus", chart_evidence: chart, votes, report: String(final.report ?? "").slice(0, 4000), agents: personas, debate: turns, models: [...models], hops };
}
