import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { callClaude, CHART_PROMPT, REVIEW_PROMPT } from "./claude";

export const claudeAnalysis = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(z.object({
    task: z.enum(["pictures", "review", "test"]),
    messages: z.array(z.object({ role: z.enum(["system", "user", "assistant"]), content: z.string().max(100_000) })).max(200),
    images: z.array(z.string().max(8_000_000).regex(/^data:image\/(jpeg|png|webp|gif);base64,/)).max(6).default([]),
  }))
  .handler(async ({ data }) => {
    const key = process.env["ANTHROPIC_API_KEY"];
    return callClaude(key, [
      { role: "system", content: data.task === "pictures" ? CHART_PROMPT : REVIEW_PROMPT },
      ...(data.task === "test" ? [{ role: "user" as const, content: "Reply with Connected." }] : data.messages),
    ], data.images);
  });