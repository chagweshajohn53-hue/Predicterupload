import { chatBody, chatEndpoint, hasKeys, relay, type Msg } from "./providers";
import { getVault, setVault, type ChainEntry } from "./vault";
import { expandChain } from "./pool";
import { supportsImages } from "./vision";

export type Attempt = { entry: ChainEntry; outcome: "ok" | "rate_limited" | "error" | "skipped"; detail: string };
export type ChatResult = {
  entry: ChainEntry | null;
  attempts: Attempt[];
  ttft: number;
  total: number;
  usage?: { prompt_tokens?: number; completion_tokens?: number; total_tokens?: number } | undefined;
};

/** Parse "2m59.5s", "7.6s", "120ms", "30", epoch ms/seconds → milliseconds from now. */
export function parseReset(v: string | null | undefined): number | null {
  if (!v) return null;
  const s = v.trim();
  if (/^\d+(\.\d+)?$/.test(s)) {
    const n = Number(s);
    if (n > 1e12) return Math.max(0, n - Date.now());
    if (n > 1e9) return Math.max(0, n * 1000 - Date.now());
    return n * 1000;
  }
  const m = s.match(/^(?:(\d+)h)?(?:(\d+)m(?!s))?(?:(\d+(?:\.\d+)?)s)?(?:(\d+)ms)?$/);
  if (!m || !m[0]) return null;
  return ((+(m[1] ?? 0)) * 3600 + (+(m[2] ?? 0)) * 60 + +(m[3] ?? 0)) * 1000 + +(m[4] ?? 0);
}

export function isRateLimit(status: number, text: string) {
  return status === 429 || status === 402 || /rate.?limit|quota|exhaust|too many requests|resource_exhausted|capacity/i.test(text);
}

function recordStatus(id: string, res: Response) {
  const h = res.headers;
  setVault((s) => ({
    ...s,
    status: {
      ...s.status,
      [id]: {
        remainingReq: h.get("x-ratelimit-remaining-requests") ?? h.get("x-ratelimit-remaining") ?? undefined,
        remainingTok: h.get("x-ratelimit-remaining-tokens") ?? undefined,
        resetReq: h.get("x-ratelimit-reset-requests") ?? h.get("x-ratelimit-reset") ?? undefined,
        lastStatus: res.status,
        at: Date.now(),
      },
    },
  }));
}

function cooldown(id: string, ms: number, reason: string) {
  setVault((s) => ({ ...s, cooldowns: { ...s.cooldowns, [id]: { until: Date.now() + ms, reason } } }));
}

export async function runChat(opts: {
  messages: Msg[];
  images?: string[];
  signal?: AbortSignal;
  onToken: (t: string) => void;
  onAttempt: (a: Attempt) => void;
  onStart: (e: ChainEntry) => void;
}): Promise<ChatResult> {
  const { keys: baseKeys, chain, cooldowns } = getVault();
  const attempts: Attempt[] = [];
  const push = (a: Attempt) => {
    attempts.push(a);
    opts.onAttempt(a);
  };
  const t0 = performance.now();

  for (const entry of expandChain(chain.filter((c) => c.enabled), baseKeys)) {
    if (opts.images?.length && !supportsImages(entry)) continue;
    const keys = entry.keys;
    const cd = cooldowns[entry.id];
    if (cd && cd.until > Date.now()) {
      push({ entry, outcome: "skipped", detail: `cooling down (${Math.ceil((cd.until - Date.now()) / 1000)}s)` });
      continue;
    }
    if (!hasKeys(entry.provider, keys)) {
      push({ entry, outcome: "skipped", detail: "no API key" });
      continue;
    }
    opts.onStart(entry);
    const { url, auth } = chatEndpoint(entry.provider, keys);
    const start = performance.now();
    let res: Response;
    try {
      const signal = opts.signal ? AbortSignal.any([opts.signal, AbortSignal.timeout(45_000)]) : AbortSignal.timeout(45_000);
      res = await relay(url, { auth, body: chatBody(entry.provider, entry.model, opts.messages, opts.images), contentType: "application/json", signal });
    } catch (e) {
      if (opts.signal?.aborted) throw e;
      push({ entry, outcome: "error", detail: String(e) });
      continue;
    }
    recordStatus(entry.id, res);
    if (!res.ok) {
      const text = await res.text();
      if (isRateLimit(res.status, text)) {
        const ms = parseReset(res.headers.get("retry-after")) ?? parseReset(res.headers.get("x-ratelimit-reset-requests")) ?? parseReset(res.headers.get("x-ratelimit-reset")) ?? 60_000;
        cooldown(entry.id, Math.max(ms, 5_000), `HTTP ${res.status}`);
        push({ entry, outcome: "rate_limited", detail: `HTTP ${res.status} · cooldown ${Math.round(ms / 1000)}s` });
      } else {
        push({ entry, outcome: "error", detail: `HTTP ${res.status}: ${text.slice(0, 140)}` });
      }
      continue;
    }

    // Stream SSE
    let ttft = 0;
    let got = false;
    let usage: ChatResult["usage"];
    try {
      if (!res.body) throw new Error("The model returned no response stream.");
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let buf = "";
      outer: for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const lines = buf.split("\n");
        buf = lines.pop() ?? "";
        for (const line of lines) {
          const l = line.trim();
          if (!l.startsWith("data:")) continue;
          const data = l.slice(5).trim();
          if (data === "[DONE]") break outer;
          let j: any;
          try {
            j = JSON.parse(data);
          } catch {
            continue;
          }
          if (j.error) throw new Error(typeof j.error === "string" ? j.error : j.error.message ?? "stream error");
          const delta = j.choices?.[0]?.delta?.content;
          if (delta) {
            if (!got) ttft = performance.now() - start;
            got = true;
            opts.onToken(delta);
          }
          if (j.usage) usage = j.usage;
        }
      }
    } catch (e) {
      if (opts.signal?.aborted) throw e;
      {
        const msg = String(e);
        if (isRateLimit(0, msg)) cooldown(entry.id, 60_000, "stream quota");
        push({ entry, outcome: isRateLimit(0, msg) ? "rate_limited" : "error", detail: msg.slice(0, 140) });
        continue;
      }
    }
    if (!got) {
      push({ entry, outcome: "error", detail: "empty response" });
      continue;
    }
    push({ entry, outcome: "ok", detail: "served" });
    return { entry, attempts, ttft, total: performance.now() - t0, usage };
  }
  return { entry: null, attempts, ttft: 0, total: performance.now() - t0 };
}
