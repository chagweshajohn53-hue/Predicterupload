import { createServerOnlyFn } from "@tanstack/react-start";
import { cleanKeys, cleanChain, type ChainEntry, type Keys } from "./vault";

export type SavedRelay = { keys: Keys; chain: ChainEntry[] };

/** Personal-token lookup only; never use this privileged client for ordinary account reads. */
export const lookupRelayToken = createServerOnlyFn(async (token: string): Promise<SavedRelay | null> => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin.from("vaults").select("data")
    .eq("data->keys->>apiToken", token).maybeSingle();
  if (error) throw new Error("Token lookup unavailable");
  if (!data) return null;
  const vault = data.data as unknown as SavedRelay;
  if (vault.keys?.apiToken !== token || !Array.isArray(vault.chain)) return null;
  return { keys: cleanKeys(vault.keys), chain: cleanChain(vault.chain) };
});